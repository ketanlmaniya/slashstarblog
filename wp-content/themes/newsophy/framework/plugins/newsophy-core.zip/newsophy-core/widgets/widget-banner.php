<?php
if ( ! class_exists( 'newsophy_banner_widget' ) ) {
	class newsophy_banner_widget extends WP_Widget { 
		
		// Widget Settings

		public function __construct() {
			$widget_ops = array('description' => __('Display image with link.', 'newsophy-core') );
			$control_ops = array( 'width' => 300, 'height' => 350, 'id_base' => 'widget_banner' );
			parent::__construct( 'widget_banner', __('(Newsophy) Banner with Link', 'newsophy-core'), $widget_ops, $control_ops );
			add_action('admin_enqueue_scripts', array($this, 'admin_setup'));
		}
		/**
		 * Enqueue all the javascript.
		*/
		public function admin_setup() {
			global $pagenow;
	    if($pagenow !== 'widgets.php' && $pagenow !== 'customize.php') return;
	    wp_enqueue_media();
	    wp_enqueue_script('image-select', TS_PLUGIN_URL.'js/image-select.js', array(), 1.0);
	    wp_register_style( 'namespace', TS_PLUGIN_URL.'css/plugins-style.css' );
	    wp_enqueue_style( 'namespace' );
		}


		// Widget Output
		function widget($args, $instance) {
			extract($args);		
      $title = apply_filters('widget_title', $instance['title']);
			$image_tmp = wp_get_attachment_image_src($instance['image_id'], 'newsophy-big-thumb');
	    $image_url = $image_tmp[0];
	    $target =  $instance['banner_target']?? null;;

	    if ($target == 'true') {
	    	$trg = '_blank';
	    }
	    else {
	    	$trg = '_self';
	    }

	    echo $target;

			// ------
			echo $before_widget;
			if ( $title !='' ) echo ''.$before_title . $title . $after_title;
			?>
				<div class="image-banner">
					<div class="bg-image">
							<?php if($instance['image']): 
							echo '<a href="'.esc_url($instance['banner_link']).'" class="img-banner" target="'.$trg.'">';	?>
							<img src="<?php echo esc_url($image_url);?>" alt="<?php echo esc_url($title);?>"></a>
						<?php endif; ?>
					</div>
				</div>
			<?php
			echo $after_widget;
			// ------
		}
		
		// Update
		function update( $new_instance, $old_instance ) { 
			$instance = $old_instance; 
			$instance['title'] = $new_instance['title'];
			$instance['image'] = $new_instance['image'];
			$instance['image_id'] = $new_instance['image_id'];
			$instance['banner_link'] = $new_instance['banner_link'];
			$instance['banner_target'] = $new_instance['banner_target'];
			return $instance;
		}
		
		// Backend Form
		function form($instance) {
	
			$defaults = array('image' => '', 'banner_link' => '', 'banner_target' => 'true', 'title' => '', 'image_id' => '');
			$instance = wp_parse_args((array) $instance, $defaults); 
			$image_tmp = wp_get_attachment_image_src($instance['image_id'], 'medium');
	    $image_url = $image_tmp[0];
			?>
			<p>            
		  	<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title' ); ?></label>
		      <input class="widefat" type="text" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>"/>
		  </p>

			<p>
				<input type="hidden" class="widefat widget-image-input" id="<?php echo esc_attr($this->get_field_id('image')); ?>_media_url" name="<?php echo esc_attr($this->get_field_name('image')); ?>" value="<?php echo esc_attr($instance['image']); ?>" />
				<input type="hidden" class="widefat widget-image-id" id="<?php echo esc_attr($this->get_field_id('image')); ?>_media_id" name="<?php echo esc_attr($this->get_field_name('image_id')); ?>" value="<?php echo esc_attr($instance['image_id']); ?>" />
				<a href="#" class="upload_image_button button button-pnewsophyry" id="<?php echo esc_attr($this->get_field_id('image')); ?>"><?php _e('Select Background Image', 'newsophy-core'); ?></a>
				<a href="#" class="delete_image_button button btn-red <?php echo esc_attr( !$image_url ? 'hidden' : '' ); ?>" id="<?php echo esc_attr($this->get_field_id('image')); ?>"><?php _e('Delete Image', 'newsophy-core'); ?></a>
	      <div class="ts-wid-image" id="image">
	         <img id="<?php echo esc_attr($this->get_field_id('image')); ?>_image_url" src="<?php echo $image_url ?>" alt=""> 
	      </div>
			</p>

		  <p>            
		  	<label for="<?php echo $this->get_field_id( 'banner_link' ); ?>"><?php _e( 'Banner url' ); ?></label>
		    <input class="widefat" type="text" id="<?php echo $this->get_field_id( 'banner_link' ); ?>" name="<?php echo $this->get_field_name( 'banner_link' ); ?>" value="<?php echo $instance['banner_link']; ?>"/>
		  </p>

		  <p>            
		  	<label for="<?php echo $this->get_field_id( 'banner_target' ); ?>"><?php _e( 'Open in a new Tab' ); ?></label>
		    <input class="widefat" type="checkbox" id="<?php echo $this->get_field_id( 'banner_target' ); ?>" name="<?php echo $this->get_field_name( 'banner_target' ); ?>" value="<?php echo $instance['banner_target']; ?>" checked />
		  </p>
			
	    <?php }
	}
}

// Add Widget
function newsophy_banner_widget_init() {
	register_widget('newsophy_banner_widget');
}
add_action('widgets_init', 'newsophy_banner_widget_init');

?>