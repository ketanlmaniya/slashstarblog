<?php
if ( ! class_exists( 'newsophy_social_widget' ) ) {

 class newsophy_social_widget extends WP_Widget {

    // Widget setup

    public $socials = array(
    'Facebook' => array(
        'title' => 'facebook',
        'name' => 'facebook_username',
        'link' => '*',
        'icon'=>'icon-facebook',
    ),
    'Twitter' => array(
        'title' => 'twitter',
        'name' => 'twitter_username',
        'link' => '*',
        'icon'=>'icon-twitter-1',
    ),
    'Instagram' => array(
        'title' => 'instagram',
        'name' => 'instagram_username',
        'link' => '*',
        'icon'=>'icon-instagram',
    ),
    'YouTube' => array(
        'title' => 'youtube',
        'name' => 'youtube_username',
        'link' => '*',
        'icon'=>'icon-youtube-play',
    ),
    'Vimeo' => array(
        'title' => 'vimeo',
        'name' => 'vimeo_username',
        'link' => '*',
        'icon'=>'icon-vimeo',
    ),
    'Linkedin' => array(
        'title' => 'linkedin',
        'name' => 'linkedin_username',
        'link' => '*',
        'icon'=>'icon-linkedin',
    ),
    'Pinterest' => array(
        'title' => 'pinterest',
        'name' => 'pinterest_username',
        'link' => '*',
        'icon'=>'icon-pinterest',
    ),
    'Dribbble' => array(
        'title' => 'dribbble',
        'name' => 'dribbble_username',
        'link' => '*',
        'icon'=>'icon-dribbble',
    ),
    'Flickr'  => array(
        'title' => 'flickr',
        'name' => 'flickr_username',
        'link' => '*',
        'icon'=>'icon-flickr',
    ),
    'Tumblr'  => array(
        'title' => 'tumblr',
        'name' => 'tumblr_username',
        'link' => '*',
        'icon'=>'icon-tumblr',
    ),
    'Snapchat'  => array(
        'title' => 'snapchat',
        'name' => 'snapchat_username',
        'link' => '*',
        'icon'=>'icon-snapchat-ghost',
    ),
    'TikTok'  => array(
        'title' => 'tiktok',
        'name' => 'tiktok_username',
        'link' => '*',
        'icon'=>'icon-logo-tiktok',
    ),
    'Mastodone'  => array(
        'title' => 'mastodon',
        'name' => 'mastodone_username',
        'link' => '*',
        'icon'=>'icon-mastodon',
    ),
    'VK'  => array(
        'title' => 'vk',
        'name' => 'vk_username',
        'link' => '*',
        'icon'=>'icon-vkontakte',
    ),
    'SoundCloud'  => array(
        'title' => 'sSoundcloud',
        'name' => 'soundcloud_username',
        'link' => '*',
        'icon'=>'icon-soundcloud',
    ),
    'Skype' => array(
        'title' => 'skype',
        'name' => 'skype_username',
        'link' => '*',
        'icon'=>'icon-skype',
    ),
    'Telegram' => array(
        'title' => 'telegram',
        'name' => 'telegram_username',
        'link' => '*',
        'icon'=>'icon-paper-plane',
    ),
    'RSS' => array(
        'title' => 'rss',
        'name' => 'rss_username',
        'link' => '*',
        'icon'=>'icon-rss',
    )
  );
    
    function __construct() {
        $widget_ops = array( 'description' => __('A widget that displays your social links', 'newsophy') );
        $control_ops = array( 'width' => 400, 'height' => 350, 'id_base' => 'newsophy_social_widget' );
        parent::__construct( 'newsophy_social_widget', __('(Newsophy) Social Links', 'newsophy'), $widget_ops, $control_ops );
    }

    // Widget Output
    function widget( $args, $instance ) {
    extract( $args );
    $title = apply_filters('widget_title', $instance['title']);
    echo $before_widget;
    if ( $title !='' ) echo $before_title . $title . $after_title;
    ?>
    <div class="social-widget">
      <?php   
        foreach ($this->socials as $key => $social) {
            if (!empty($instance[$social['name']])) {
                echo '<div class="social-wid"><a href="'.str_replace('*', esc_attr($instance[$social['name']]), $social['link']).'" target="_blank" title="'. esc_attr($key).'"><i class="'.esc_attr( $social['icon']).' '.esc_attr( $social['title']).'"></i>'.$social['title'].'</a></div>';
                }
            } 
        ?>
    </div>    
    <?php 
    echo $after_widget;
    }

    // Update
    function update( $new_instance, $old_instance ) {  
        $instance = $old_instance; 
        $instance = $new_instance;
        $instance['title'] = sanitize_text_field($new_instance['title']);
        return $instance;
    }

    // Backend Form
    function form($instance) {
    $defaults = array('title' => '');
    $instance = wp_parse_args((array) $instance, $defaults);
    ?>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php _e('Title:','newsophy'); ?></label>
            <input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" value="<?php echo esc_attr($instance['title']); ?>" />
        </p>
        <?php
            foreach ($this->socials as $key => $social) {
                ?>
                <p>
                <label for="<?php echo esc_attr($this->get_field_id($social['name'])); ?>"><?php echo esc_html($key); ?>:</label>
                <input class="widefat" id="<?php echo esc_attr($this->get_field_id($social['name'])); ?>" type="text"
                    name="<?php echo esc_attr($this->get_field_name($social['name'])); ?>"
                    value="<?php echo isset($instance[$social['name']]) ? esc_attr($instance[$social['name']]) : ''; ?>"/>
                </p>
        <?php }
    }

}

// Add Widget  
  function newsophy_social_widget_init() {
      register_widget( 'newsophy_social_widget' );
  }
  add_action( 'widgets_init', 'newsophy_social_widget_init' );

}
?>