<?php
if ( ! class_exists( 'newsophy_about_me_widget' ) ) {
 class newsophy_about_me_widget extends WP_Widget { 

	// Widget setup

	public function __construct() {
		$widget_ops = array('description' => __('Display informations about author', 'newsophy-core') );
		$control_ops = array( 'width' => 300, 'height' => 350, 'id_base' => 'aboutme' );
		parent::__construct( 'aboutme', __('(Newsophy) About Me', 'newsophy-core'), $widget_ops, $control_ops );
		add_action('admin_enqueue_scripts', array($this, 'admin_setup'));
	}
	/**
	 * Enqueue all the javascript.
	 */
	public function admin_setup() {
		global $pagenow;
    if($pagenow !== 'widgets.php' && $pagenow !== 'customize.php') return;
	  wp_enqueue_media();
    wp_enqueue_script('about-me-widget', TS_PLUGIN_URL.'js/image-select.js', array(), 1.0);
    wp_register_style( 'namespace', TS_PLUGIN_URL.'css/plugins-style.css' );
    wp_enqueue_style( 'namespace' );
	}

	// Widget Output
	function widget($args, $instance) {
		extract($args);
		$title = apply_filters('widget_title', $instance['title']);
		$image_tmp = wp_get_attachment_image_src($instance['image_id'], 'medium');
		$image_url = $image_tmp[0];

		// ------
		echo ''.$before_widget;
		if ( $title !='' ) echo ''.$before_title . $title . $after_title;
		?>
			<div class="about-widget">
				<?php if($instance['image']): ?>
				<div class="about-img">
          <img src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_url($title); ?>">
        </div>
				<?php endif; ?>
        <div class="about-content">
          <?php if($instance['header']): ?>
          <h5>   
            <?php echo apply_filters( 'widget_text', $instance['header'], $instance, $this ); ?>
          </h5>
          <?php endif; ?>
          <?php if($instance['content']): ?> 
          <div class="about-author-content">    
					  <?php echo apply_filters( 'widget_text', $instance['content'], $instance, $this ); ?>
					</div>  
					<?php endif; ?>
           <?php if($instance['signature']): ?>
          <div class="about-author-signature">  
            <img src="<?php echo apply_filters( 'widget_text', $instance['signature'], $instance, $this ); ?>" alt=""> 
          </div>
          <?php endif; ?>
				</div>
      </div>
		<?php
		echo ''.$after_widget;
		// ------
	}
	
	// Update
	function update( $new_instance, $old_instance ) {  
		$instance = $old_instance; 
		$instance['title'] = sanitize_text_field($new_instance['title']);
    $instance['header'] = $new_instance['header'];
		$instance['image'] = $new_instance['image'];
		$instance['image_id'] = $new_instance['image_id'];
		$instance['content'] = $new_instance['content'];
    $instance['signature'] = $new_instance['signature'];
    $instance['sign_id'] = $new_instance['sign_id'];
		return $instance;
	}
	
	// Backend Form
	function form($instance) {
		$defaults = array('title' => '', 'image' => '', 'header' => '', 'image_id' => '', 'content' => '', 'signature' => '', 'sign_id' => '');
		$instance = wp_parse_args((array) $instance, $defaults); 
    $image_tmp = wp_get_attachment_image_src($instance['image_id'], 'medium');
    $image_url = $image_tmp[0];
    $sign_tmp = wp_get_attachment_image_src($instance['sign_id'], 'medium');
    $sign_url = $sign_tmp[0];
    ?>

		<p>
			<label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php _e('Title:','newsophy'); ?></label>
			<input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" value="<?php echo esc_attr($instance['title']); ?>" />
		</p>

		<p>
			<input type="hidden" class="widefat widget-image-input" id="<?php echo esc_attr($this->get_field_id('image')); ?>_media_url" name="<?php echo esc_attr($this->get_field_name('image')); ?>" value="<?php echo esc_attr($instance['image']); ?>" />
			<input type="hidden" class="widefat widget-image-id" id="<?php echo esc_attr($this->get_field_id('image')); ?>_media_id" name="<?php echo esc_attr($this->get_field_name('image_id')); ?>" value="<?php echo esc_attr($instance['image_id']); ?>" />
			<a href="#" class="upload_image_button button button-pnewsophyry" id="<?php echo esc_attr($this->get_field_id('image')); ?>"><?php _e('Select Author Image', 'newsophy-core'); ?></a>
			<a href="#" class="delete_image_button button btn-red <?php echo esc_attr( !$image_url ? 'hidden' : '' ); ?>" id="<?php echo esc_attr($this->get_field_id('image')); ?>"><?php _e('Delete Image', 'newsophy-core'); ?></a>
      <div class="ts-wid-image" id="image">
         <img id="<?php echo esc_attr($this->get_field_id('image')); ?>_image_url" src="<?php echo $image_url ?>" alt=""> 
      </div>
		</p>

    <p>
      <label for="<?php echo esc_attr($this->get_field_id('header')); ?>"><?php _e('Header:','newsophy'); ?></label>
      <input type="text" class="widefat" id="<?php echo esc_attr($this->get_field_id('header')); ?>" name="<?php echo esc_attr($this->get_field_name('header')); ?>" value="<?php echo esc_attr($instance['header']); ?>" />
    </p>
		
    <p>
			<label for="<?php echo esc_attr($this->get_field_id('content')); ?>"><?php _e('Content:','newsophy'); ?></label>
			<textarea class="widefat" rows="2" cols="20" id="<?php echo esc_attr($this->get_field_id('content')); ?>" name="<?php echo esc_attr($this->get_field_name('content')); ?>"><?php echo esc_textarea($instance['content']); ?></textarea>
		</p>

    <p>
      <input type="hidden" class="widefat widget-image-input" id="<?php echo esc_attr($this->get_field_id('signature')); ?>_signature_url" name="<?php echo esc_attr($this->get_field_name('signature')); ?>" value="<?php echo esc_attr($instance['signature']); ?>" />
       <input type="hidden" class="widefat widget-image-id" id="<?php echo esc_attr($this->get_field_id('signature')); ?>_signature_id" name="<?php echo esc_attr($this->get_field_name('sign_id')); ?>" value="<?php echo esc_attr($instance['sign_id']); ?>" />
      <a href="#" class="upload_image_button button button-pnewsophyry" id="<?php echo esc_attr($this->get_field_id('signature')); ?>"><?php _e('Select Signature', 'newsophy-core'); ?></a>
      <a href="#" class="delete_image_button button btn-red <?php echo esc_attr( !$sign_url ? 'hidden' : '' ); ?>" id="<?php echo esc_attr($this->get_field_id('signature')); ?>"><?php _e('Delete Signature', 'newsophy-core'); ?></a>
      <div class="ts-wid-image" id="image">
         <img id="<?php echo esc_attr($this->get_field_id('signature')); ?>_sign_url" src="<?php echo $sign_url ?>" alt=""> 
      </div>
    </p>
	<?php }
  
  }

// Add Widget
  function newsophy_widget_about_init() {
	  register_widget('newsophy_about_me_widget');
  }
  add_action('widgets_init', 'newsophy_widget_about_init');

}
?>