<?php

class newsophy_category_widget extends WP_Widget { 
	
	// Widget Settings
	public function __construct() {
		$widget_ops = array('description' => __('Display category', 'newsophy-core') );
		$control_ops = array( 'width' => 300, 'height' => 350, 'id_base' => 'category' );
		parent::__construct( 'category', __('(Newsophy) Category', 'newsophy-core'), $widget_ops, $control_ops );
		add_action('admin_enqueue_scripts', array($this, 'admin_setup'));
	}
	/**
	 * Enqueue all the javascript.
	 */
		public function admin_setup() {
			global $pagenow;
	    if($pagenow !== 'widgets.php' && $pagenow !== 'customize.php') return;
	    wp_enqueue_media();
	    wp_enqueue_script('image-select', TS_PLUGIN_URL.'js/image-select.js', array(), 1.0);
	    wp_register_style( 'namespace', TS_PLUGIN_URL.'css/plugins-style.css' );
	    wp_enqueue_style( 'namespace' );
		}

	// Widget Output
	function widget($args, $instance) {
		extract($args);
		$title = apply_filters('widget_title', $instance['title']);
		$category = $instance['category'];
		$cat_tag =  ( ! empty( $instance['cattag'] ) ) ? $instance['cattag'] : '';
		// ------
		echo '<div class="catwid">';
		echo ''.$before_widget;

		$catObj = get_category_by_slug( $category );
		if(!empty($catObj)){
		?>
			<div class="category-wid">
				<?php if($instance['image']): ?>
				<div class="category-img">
					<div class="overlay"></div>	
					<?php if( $instance['image_id'] ){
						$image_tmp = wp_get_attachment_image_src($instance['image_id'], 'medium');
						$image_url = $image_tmp[0];
						if($image_url){
							echo '<img src="'.esc_url($image_url).'" alt="'.$title.'">';
						}
					}?>
				</div>
				<?php endif; 
       
                echo '<h4><a href="'.esc_url(get_category_link($catObj->term_id)).'" class="category-link">'.$catObj->name.'</a></h4>'; 
     
				?>
			
			</div>

		<?php
		}
		echo ''.$after_widget;
		echo '</div>';
		// ------
	}
	
	// Update
	function update( $new_instance, $old_instance ) {  
		$instance = $old_instance; 
		$instance['title'] = sanitize_text_field($new_instance['category']);
		$instance['category'] = sanitize_text_field($new_instance['category']);
		$instance['image'] = $new_instance['image'];
		$instance['image_id'] = $new_instance['image_id'];
		$instance['cattag'] = strip_tags( $new_instance['cattag'] );
		return $instance;
	}
	
	// Backend Form
	function form($instance) {
		
		$defaults = array('title' => '', 'image' => '', 'image_id' => '', 'category' => '');
		$instance = wp_parse_args((array) $instance, $defaults); 
		$image_tmp = wp_get_attachment_image_src($instance['image_id'], 'medium');
	  $image_url = $image_tmp[0];
		$categs = array();
	    $catquery = get_terms( 'category', array('hide_empty' => false));
	    if( $catquery ){
	        foreach ( $catquery as $post ) {
	            $categs[ $post->slug ] = $post->name;
	        }
	    }
		?>

			<p style="display: none;">            
		  	<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title' ); ?></label>
		      <input class="widefat" type="text" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>"/>
		  </p>
		
			<p>
				<input type="hidden" class="widefat widget-image-input" id="<?php echo esc_attr($this->get_field_id('image')); ?>_media_url" name="<?php echo esc_attr($this->get_field_name('image')); ?>" value="<?php echo esc_attr($instance['image']); ?>" />
				<input type="hidden" class="widefat widget-image-id" id="<?php echo esc_attr($this->get_field_id('image')); ?>_media_id" name="<?php echo esc_attr($this->get_field_name('image_id')); ?>" value="<?php echo esc_attr($instance['image_id']); ?>" />
				<a href="#" class="upload_image_button button button-pnewsophyry" id="<?php echo esc_attr($this->get_field_id('image')); ?>"><?php _e('Select Image', 'newsophy-core'); ?></a>
				<a href="#" class="delete_image_button button btn-red <?php echo esc_attr( !$image_url ? 'hidden' : '' ); ?>" id="<?php echo esc_attr($this->get_field_id('image')); ?>"><?php _e('Remove Image', 'newsophy-core'); ?></a>
	      <div class="ts-wid-image" id="image">
	         <img id="<?php echo esc_attr($this->get_field_id('image')); ?>_image_url" src="<?php echo $image_url ?>" alt=""> 
	      </div>
			</p>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('category')); ?>"><?php _e('Select category:','newsophy-core'); ?></label>
			<?php
            if(isset($instance['category'])) $category = $instance['category'];
            ?>
            <select class="widefat" id="<?php echo $this->get_field_id( 'category' ); ?>" name="<?php echo $this->get_field_name( 'category' ); ?>">
                <?php
                $op = '<option value="%s"%s>%s</option>';
                foreach ($categs as $key=>$value ) {
                    if ($category === $key) {
                        printf($op, $key, ' selected="selected"', $value);
                    } else {
                        printf($op, $key, '', $value);
                    }
                }
                ?>
            </select>
		</p>
		<?php if (get_theme_mod( 'newsophy_multiple_issues' )) : ?>
      <p>            
        <label for="<?php echo $this->get_field_id( 'cattag' ); ?>"><?php _e( 'Tag' ); ?></label>
        <input class="widefat" type="text" id="<?php echo $this->get_field_id( 'cattag' ); ?>" name="<?php echo $this->get_field_name( 'cattag' ); ?>" value="<?php echo $instance['cattag']; ?>"/>
      </p>
    <?php endif ?>
		
    <?php }
}

// Add Widget
function newsophy_category_widget_init() {
	register_widget('newsophy_category_widget');
}
add_action('widgets_init', 'newsophy_category_widget_init');

?>