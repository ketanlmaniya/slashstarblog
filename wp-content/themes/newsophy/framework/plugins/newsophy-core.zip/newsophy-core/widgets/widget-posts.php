<?php
/**
 * @package Newsophy
 */
if ( ! class_exists( 'newsophy_latest_posts_widget' ) ) {

 class newsophy_latest_posts_widget extends WP_Widget {

    // Widget setup
    
    function __construct() {
        $widget_options = array( 'description' =>  esc_html__('A widget that displays your latest posts', 'newsophy'), 
   'customize_selective_refresh'   => true,
    );
        parent::__construct( 'newsophy_latest_posts_widget',  esc_html__('(Newsophy) Latest Posts', 'newsophy'), $widget_options );
    }

        /**
         * Front-end display of widget.
         *
         * @see WP_Widget::widget()
         *
         * @param array $args     Widget arguments.
         * @param array $instance Saved values from database.
         */
        
        public function widget( $args, $instance ) {
          if ( ! isset( $args['widget_id'] ) ) { $args['widget_id'] = $this->id; }

        /* Get variables from widget settings */
        $title =( ! empty( $instance['title'] ) ) ? $instance['title'] : esc_html__( 'Recent Posts','newsophy' );

        $title = apply_filters( 'widget_title', $title, $instance, $this->id_base );

        $categories = $instance['categories'];
        $number = $instance['number'];

        $query = array('showposts' => $number, 'nopaging' => 0, 'post_status' => 'publish', 'cat' => $categories);
        
        $loop = new WP_Query($query);
 
        echo $args['before_widget']; 
        /* Display the widget title if one was input */
        if( $title ): 
        echo $args['before_title'];  
        echo esc_html( $title );  
        echo $args['after_title']; 
        endif;

        $pcnt = 1; 
        ?>
        <ul class="recent-posts">
        <?php  while ($loop->have_posts()) : $loop->the_post(); ?>
        <?php $pcnt = str_pad($pcnt,2,"0",STR_PAD_LEFT); ?>
        <li class="recent-posts-item">
                    <?php if ((function_exists('has_post_thumbnail')) && (has_post_thumbnail())) : ?>
                      <div class="recent-posts-image">
                          <a href="<?php echo get_permalink() ?>" rel="bookmark"><?php the_post_thumbnail('newsophy-mid-thumb', array('class' => 'side-item-thumb')); ?></a>
            <span class="postnum"><?php echo $pcnt; ?></span>
                      </div>
                    <?php endif; ?>
                    <div class="recent-posts-text">
                        <div class="categ">
                            <?php echo trs_render_categories('no-thumb'); ?>
                        </div>
                        <h4><a href="<?php echo get_permalink() ?>" rel="bookmark"><?php the_title(); ?></a></h4>
                        <span class="recent-posts-meta"><?php the_time( get_option('date_format') ); ?></span>
                </div>
                </li>
                <?php $pcnt++; ?>
                <?php endwhile; ?>
                <?php echo $args['after_widget']; ?>
                <?php wp_reset_postdata(); ?>
        </ul>
            
        <?php 
    }
    /**
     * Sanitize widget form values as they are saved.
     *
     * @see WP_Widget::update()
     *
     * @param array $new_instance Values just sent to be saved.
     * @param array $old_instance Previously saved values from database.
     *
     * @return array Updated safe values to be saved.
     */
    public function update( $new_instance, $old_instance ) {
        $instance = $old_instance;
        /* Strip tags for title and name to remove HTML */
        $instance['title'] = strip_tags( $new_instance['title'] );
        $instance['categories'] = $new_instance['categories'];
        $instance['number'] = strip_tags( $new_instance['number'] );
        return $instance;
    }

    public function form( $instance ) {

        /* Set up some default widget settings. */
        $defaults = array( 'title' => __('Recent Posts', 'newsophy'), 'number' => 5, 'categories' => '');
        $instance = wp_parse_args( (array) $instance, $defaults ); ?>

        <!-- Widget Title: Text Input -->
        <p>
            <label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e('Title:', 'newsophy'); ?></label>
            <input  type="text" class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>"  />
        </p>
        
        <!-- Category -->
        <p>
        <label for="<?php echo $this->get_field_id('categories'); ?>">Filter by Category:</label> 
        <select id="<?php echo $this->get_field_id('categories'); ?>" name="<?php echo $this->get_field_name('categories'); ?>" class="widefat categories" style="width:100%;">
            <option value='all' <?php if ('all' == $instance['categories']) echo 'selected="selected"'; ?>>All categories</option>
            <?php $categories = get_categories('hide_empty=0&depth=1&type=post'); ?>
            <?php foreach($categories as $category) { ?>
            <option value='<?php echo $category->term_id; ?>' <?php if ($category->term_id == $instance['categories']) echo 'selected="selected"'; ?>><?php echo $category->cat_name; ?></option>
            <?php } ?>
        </select>
        </p>
        
        <!-- Number of posts -->
        <p>
            <label for="<?php echo $this->get_field_id( 'number' ); ?>"><?php _e('Number of posts to show:', 'newsophy'); ?></label>
            <input  type="text" class="widefat" id="<?php echo $this->get_field_id( 'number' ); ?>" name="<?php echo $this->get_field_name( 'number' ); ?>" value="<?php echo $instance['number']; ?>" size="3" />
        </p>
    <?php }
  
  }

  function newsophy_latest_posts_widget_init() {
      register_widget( 'newsophy_latest_posts_widget' );
  }
  add_action( 'widgets_init', 'newsophy_latest_posts_widget_init' );

}
?>