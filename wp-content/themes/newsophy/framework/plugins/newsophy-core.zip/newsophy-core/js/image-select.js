jQuery(document ).ready( function(){
    function media_upload( button_class ) {
        var _custom_media = true,
            _orig_send_attachment = wp.media.editor.send.attachment;
          jQuery('body').on('click', button_class, function(e) {
            var button_id ='#'+jQuery(this).attr( 'id' );
            console.log(button_id); 
            var self = jQuery(button_id);
            var send_attachment_bkp = wp.media.editor.send.attachment;
            var button = jQuery(button_id);
            var id = button.attr( 'id' ).replace( '_button', '' );
            _custom_media = true;

            wp.media.editor.send.attachment = function(props, attachment ){
                if ( _custom_media ) {
                    jQuery( button_id + '_media_id' ).val(attachment.id); 
                    jQuery( button_id + '_media_url' ).val(attachment.url).change();
                    jQuery( button_id + '_signature_id' ).val(attachment.id); 
                    jQuery( button_id + '_signature_url' ).val(attachment.url).change();
                    var imgthumb = attachment.url;
                    jQuery( button_id + '_image_url' ).attr('src', imgthumb);
                    jQuery( button_id + '_sign_url' ).attr('src', imgthumb);
                    jQuery( button_id + '.delete_image_button' ).removeClass( 'hidden' );
                } else {
                    return _orig_send_attachment.apply( button_id, [props, attachment] );
                }
              
            }
            wp.media.editor.open(button);
            return false;
          });
    }
    function media_delete( button_class ) {
            jQuery('body').on('click', button_class, function(e) {
              var button_id ='#'+jQuery(this).attr( 'id' );
                jQuery( button_id + '_media_id' ).val(''); 
                jQuery( button_id + '_media_url' ).val('').change();
                jQuery( button_id + '_image_url' ).attr('src', '');
                jQuery( button_id + '_signature_id' ).val(''); 
                jQuery( button_id + '_signature_url' ).val('').change();
                jQuery( button_id + '_sign_url' ).attr('src', '');
                jQuery( button_id + '.delete_image_button' ).addClass( 'hidden' );
            });
    }    
    media_upload( '.upload_image_button' );
    media_delete( '.delete_image_button' );
});
