<?php
/**
 * Plugin Name: Newsophy Core
 * Plugin URI: http://3styler.in
 * Description: This plugin enables core functions for Newsophy Theme.
 * Version: 1.3.0
 * Author: 3Styler
 * Author URI: http://3styler.in
 */

defined( 'ABSPATH' ) or die( 'No script kiddies please!' ); // No direct access allowed

 if ( !class_exists('tslr_theme_functions') ) {

  include_once ABSPATH . 'wp-admin/includes/plugin.php';

    define('TS_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
    define('TS_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

    /* Base paths */
    
    if( !defined('TS_THEMEPREFIX') ) define('TS_THEMEPREFIX', 'tslr');
    if( !defined('TS_FRAMEWORK_VAR') ) define('TS_FRAMEWORK_VAR', 'tslr_theme');

    
    class ThreeStyler_theme_functions {

    /* Remove WooCommerce subcategories */
    public function remove_woocommerce_hook() {
      remove_filter( 'woocommerce_product_loop_start', 'woocommerce_maybe_show_product_subcategories' );
    }

  }  

	 new ThreeStyler_theme_functions();
 }

?>