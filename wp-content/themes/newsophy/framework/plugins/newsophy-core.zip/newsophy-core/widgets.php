<?php
require_once(TS_PLUGIN_PATH.'/widgets/widget-posts.php');
require_once(TS_PLUGIN_PATH.'/widgets/widget-about.php');
require_once(TS_PLUGIN_PATH.'/widgets/widget-social.php');
require_once(TS_PLUGIN_PATH.'/widgets/widget-banner.php');
require_once(TS_PLUGIN_PATH.'/widgets/widget-category.php');
?>
